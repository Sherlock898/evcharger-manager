package com.noder.cargadorws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CargadorwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CargadorwsApplication.class, args);
	}

}
